﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Employee_Management_for_Jayant_Textile
{
    public partial class Employee_Salary : System.Web.UI.Page
    {
        MySqlConnection cn = new MySqlConnection("Server=localhost; Database=Employee_Management_for_Jayant_Textile; user=root; password=root");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataAdapter da = new MySqlDataAdapter();
        MySqlDataReader dr;



        protected void Page_Load(object sender, EventArgs e)
        {
                  


        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            String employee_name = TextBox1.Text;
            String employee_id = TextBox2.Text;
            String email_id = TextBox3.Text;
            String mobile_no = TextBox4.Text;
            String designation = TextBox5.Text;
            String department = TextBox6.Text;
            String da= TextBox7.Text;
            String hra = TextBox8.Text;
            String mid = TextBox9.Text;
            String pf = TextBox10.Text;
            String prof_tax = TextBox11.Text;
            String advance = TextBox12.Text;
            String lic = TextBox13.Text;
            String canteen = TextBox14.Text;
            String total_period = TextBox15.Text;
            String m_day = TextBox16.Text;
            String select_month = TextBox17.Text;
            String select_year = TextBox18.Text;
            String earning = TextBox19.Text;
            String deduction = TextBox20.Text;
            String bank_acc_no = TextBox21.Text;
            String net_pay = TextBox22.Text;
           
            try
            {
                cn.Close();
                cn.Open();
                String query = "insert into employee_salary(employee_name, employee_id, email_id, mobile_no, designation, department, da, hra, mid, pf, prof_tax, advance, lic, canteen, total_period, m_day, bank_acc_no, select_month, select_year, earning, deduction, net_pay ) values ('" + employee_name + "', '" + employee_id + "', '" + email_id + "', '" + mobile_no + "', '" + designation + "',  '" + department + "', '" + da + "' , '" + hra + "', '" + mid + "', '" + pf + "', '" + prof_tax + "', '" + advance + "', '" + lic + "', '" + canteen + "', '" + total_period + "', '" + m_day + "', '" + select_month + "', '" + select_year + "', '" + earning + "', '" + deduction + "', '" + bank_acc_no + "', '" + net_pay + "' )";
                cmd.Connection = cn;
                cmd.CommandText = query;
                int result = cmd.ExecuteNonQuery();

                Response.Write("<script type = 'text/javascript'> alert('Salary Has Been Created');  </script>");

                cn.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.ToString());
                Response.Write("<script type= 'text/javascript'> alert('Oh no, You Can Try Again'); </script>");


            }



        }
    }
}