﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Employee_Management_for_Jayant_Textile
{
    public partial class Employee_Menu : System.Web.UI.Page
    {

        MySqlConnection cn = new MySqlConnection("Server=localhost; Database=Employee_Management_for_Jayant_Textile; user=root; password=root");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataAdapter da = new MySqlDataAdapter();
        MySqlDataReader dr;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Write("<script type = 'text/javascript'> location= 'Employee_WorkManaging.aspx'</script>");
     
        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            Response.Write("<script type = 'text/javascript'> location= 'Employee_Loan.aspx' </script>");
     
        }

        protected void Button6_Click(object sender, EventArgs e)
        {
            Response.Write("<script type = 'text/javascript'> location= 'loan_status.aspx' </script>");
     
        }

        protected void Button8_Click(object sender, EventArgs e)
        {
            Response.Write("<script type = 'text/javascript'> location= 'Employee_Leave.aspx' </script>");
     
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Write("<script type = 'text/javascript'> location= 'Employee_Mails.aspx' </script>");
     
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Write("<script type = 'text/javascript'> location= 'Employee_Notice.aspx' </script>");
     
        }

        protected void Button9_Click(object sender, EventArgs e)
        {
            Response.Write("<script type = 'text/javascript'> location= 'leave_status.aspx' </script>");
     
        }

        protected void Button10_Click(object sender, EventArgs e)
        {
            Response.Write("<script type = 'text/javascript'> location= 'Admin_Attendence_Details.aspx' </script>");
     
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            Response.Write("<script type = 'text/javascript'> location= 'E_Salary.aspx'</script>");
     
        }

        protected void Button7_Click(object sender, EventArgs e)
        {
            Response.Write("<script type = 'text/javascript'>  location= 'My_Attendence.aspx' </script>");
     
        }
    }
}