﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Employee_Management_for_Jayant_Textile
{
    public partial class Admin_WorkManage : System.Web.UI.Page
    {

        MySqlConnection cn = new MySqlConnection("Server=localhost; Database=Employee_Management_for_Jayant_Textile; user=root; password=root");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataAdapter da = new MySqlDataAdapter();
        MySqlDataReader dr;



        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            String admin_name = TextBox1.Text;
            String task_name = TextBox2.Text;
            String task_type = TextBox3.Text;
            String due_date = TextBox4.Text;
            String assignee = TextBox5.Text;
            String task_category = TextBox6.Text;
            String department = TextBox7.Text;
            String priority = DropDownList1.SelectedValue;
            String instructions = TextBox10.Text;
            String case_file = FileUpload1.FileName;

            try
            {
                cn.Close();
                cn.Open();
                String query = "insert into admin_workmanage(admin_name, task_name, task_type, due_date, assignee, task_category, department,  priority, instructions, case_file) values ('" + admin_name + "', '" + task_name + "', '" + task_type + "', '" + due_date + "', '" + assignee + "', '" + task_category + "', '" + department + "', '"+ priority+"','"+ instructions +"', '"+ case_file +"')";
                cmd.Connection = cn;
                cmd.CommandText = query;
                int result = cmd.ExecuteNonQuery();

                Response.Write("<script type = 'text/javascript'> alert('You Are Message Have Been Delivered '); location='Admin_WorkManage.aspx'; </script>");

                cn.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.ToString());
                Response.Write("<script type= 'text/javascript'> alert('Sorry! Mail Delivery Failed');  </script>");


            }

        }
    }
}