﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Employee_Management_for_Jayant_Textile
{
    public partial class Employee_Registration : System.Web.UI.Page
    {
        MySqlConnection cn = new MySqlConnection("Server=localhost; Database=Employee_Management_for_Jayant_Textile; user=root; password=root");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataAdapter da = new MySqlDataAdapter();
        MySqlDataReader dr;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            String employee_name = TextBox1.Text;
            String employee_id = TextBox2.Text;
            String date_of_birth = TextBox3.Text;
            String email_id = TextBox4.Text;
            String mobile_no = TextBox5.Text;
            String gender = DropDownList1.SelectedValue;
            String address = TextBox7.Text;
            String highest_qualification = TextBox8.Text;
            String designation = TextBox9.Text;
            String adhar_no = TextBox10.Text;
            String voting_no = TextBox11.Text;
            String password = TextBox12.Text;
            String cpassword = TextBox13.Text;
            String applying_date = TextBox14.Text;
            String type_of_work = TextBox15.Text;
            String languages_spoken = TextBox16.Text;
            String marital_status = TextBox17.Text;
            String pancard_details = FileUpload1.FileName;
            String bank_details = FileUpload2.FileName;
            String resume = FileUpload3.FileName;

            try
            {
                cn.Close();
                cn.Open();
                String query = "insert into employee_registration(employee_name, employee_id, date_of_birth,email_id, mobile_no, gender, address, highest_qualification, designation, adhar_no, voting_no, password, cpassword, applying_date, type_of_work, languages_spoken, marital_status, pancard_details, bank_details, resume ) values ('" + employee_name + "', '" + employee_id + "', '" + date_of_birth + "','" + email_id + "', '" + mobile_no + "', '" + gender + "', '" + address + "', '" + highest_qualification + "', '" + designation + "', '" + adhar_no + "', '" + voting_no + "', '" + password + "', '" + cpassword + "', '" + applying_date + "', '" + type_of_work + "', '" + languages_spoken+ "', '" + marital_status + "', '" + pancard_details + "', '" + bank_details + "', '" + resume + "' )";
                cmd.Connection = cn;
                cmd.CommandText = query;
                int result = cmd.ExecuteNonQuery();


                Response.Write("<script type='text/javascript'> alert('Registration successfull'); location='Employee_Login.aspx'; </script>");

                cn.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.ToString());
               // Response.Write("<script type='text/javascript'> alert('Registration failed'); location='Employee_Registration.aspx'; </script>");

            }




        }




       
       
         
    }
}