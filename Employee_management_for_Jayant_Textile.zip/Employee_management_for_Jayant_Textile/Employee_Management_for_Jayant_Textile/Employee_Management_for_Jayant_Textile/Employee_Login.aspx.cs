﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Employee_Management_for_Jayant_Textile
{
    public partial class Employee_Login : System.Web.UI.Page
    {
        MySqlConnection cn = new MySqlConnection("Server=localhost; Database=Employee_Management_for_Jayant_Textile; user=root; password= root");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataAdapter da = new MySqlDataAdapter();
        MySqlDataReader dr;

        protected void Page_Load(object sender, EventArgs e)
        {
 
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            String employee_id = TextBox1.Text;
            String password = TextBox2.Text;

            try
            {
                cn.Close();
                cn.Open();

                String query = "select * from employee_registration where employee_id = '" + employee_id + "' && password= '" + password + "' ";
                cmd.Connection = cn;
                cmd.CommandText = query;
                int result = cmd.ExecuteNonQuery();
                MySqlDataReader dr = cmd.ExecuteReader();
 
                if (dr.Read())
                {
                    Session["employee_id"] = dr[2].ToString();
                    Response.Write("<script type = 'text/javascript'> alert('Login suceessful'); location= 'Employee_Menu.aspx'; </script>");
                }
                
                else
                {
                    Response.Write("<script type = 'text/javascript'> alert('Login failed'); location= 'Employee_Login.aspx'; </script>");
               
                }

                cn.Close();

            }
            catch (Exception ex)
            {
                Response.Write(ex.ToString());
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Write("<script type = 'text/javascript'> location= 'Employee_Registration.aspx'; </script>");
             
        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

    }
}