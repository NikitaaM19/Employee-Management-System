﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Employee_Management_for_Jayant_Textile
{
    public partial class Password : System.Web.UI.Page
    {
        MySqlConnection cn = new MySqlConnection("Server=localhost; Database=Employee_Management_for_Jayant_Textile; user=root; password=root");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataAdapter da = new MySqlDataAdapter();
        MySqlDataReader dr;



        protected void Page_Load(object sender, EventArgs e)
        {

        }

     

        protected void Button1_Click(object sender, EventArgs e)
        {
            String email_id = TextBox1.Text;
            String password = TextBox2.Text;
            String cpassword = TextBox3.Text;

            try
            {
                cn.Close();
                cn.Open();
                String query = "update admin_signup set password= '" + password + "', cpassword= '" + cpassword + "' where email_id = '" + email_id + "'";
                cmd.Connection = cn;
                cmd.CommandText = query;
                int result = cmd.ExecuteNonQuery();

                Response.Write("<script type = 'text/javascript'> alert('Your Password Has Been Reseted'); location='Employee_Login.aspx' </script>");

                cn.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.ToString());
               // Response.Write("<script type= 'text/javascript'> alert('Reset Failed'); </script>");


            }
        
        
        }

       
    }
}