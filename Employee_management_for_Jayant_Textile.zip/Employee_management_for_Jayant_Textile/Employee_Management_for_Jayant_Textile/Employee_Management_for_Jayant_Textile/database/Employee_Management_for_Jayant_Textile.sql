create database Employee_Management_for_Jayant_Textile;

use Employee_Management_for_Jayant_Textile;

create table Employee_Login
(
   user_id int primary key auto_increment,
   employee_id nvarchar(50),
   password nvarchar(50)
);

  create table Admin_Login
 (
	user_id int primary key auto_increment,
    username nvarchar(50),
              password nvarchar(80)
    
 );
 
 
ALTER TABLE admin_login
  ADD name nvarchar(50);
  
  ALTER TABLE admin_login
  ADD password nvarchar(50);
  
  
 ALTER TABLE admin_login
 MODIFY COLUMN name varchar(60);
  
  ALTER TABLE admin_login
  DROP COLUMN password;
  
  
 create table Employee_Registration
 (
       user_id int primary key auto_increment,
       employee_name nvarchar(50),
	   date_of_birth bigint(50),
       place_of_birth nvarchar(50),
       email_id bigint(50),
       mobile_no bigint(50),
       gender nvarchar(50),
       address nvarchar(100),
       highest_qualification nvarchar(50),
       designation nvarchar(50),
       adhar_no bigint(50),
       voting_no bigint(50),
       password nvarchar(50),
       cpassword nvarchar(50),
       applying_date bigint(50),
       type_of_work nvarchar(50),
       languages_spoken nvarchar(50),
       marital_status nvarchar(50),
       pancard_details nvarchar(50),
       bank_details nvarchar(50),
       resume nvarchar(50)
);


  ALTER TABLE employee_registration
  DROP COLUMN pancard_details;
  
  
  ALTER TABLE employee_registration
  ADD pancard_details nvarchar(500);
  
   ALTER TABLE employee_registration
  DROP COLUMN bank_details;
  
  ALTER TABLE employee_registration
  ADD bank_details nvarchar(500);
  
   ALTER TABLE employee_registration
  DROP COLUMN resume;
  
    ALTER TABLE employee_registration
  ADD resume nvarchar(500);
  
    ALTER TABLE employee_registration
  modify email_id nvarchar(50); 
  
  ALTER TABLE admin_signup
  modify email_id varchar(350);
  
  
  
  
 create table Employee_Registration
 (
       user_id int primary key auto_increment,
       employee_name nvarchar(50),
	   employee_id nvarchar(50),
       date_of_birth nvarchar(50),
       email_id nvarchar(50),
       mobile_no bigint(50),
       gender nvarchar(50),
       address nvarchar(100),
       highest_qualification nvarchar(50),
       designation nvarchar(50),
       adhar_no bigint(50),
       voting_no bigint(50),
       password nvarchar(50),
       cpassword nvarchar(50),
       applying_date bigint(50),
       type_of_work nvarchar(50),
       languages_spoken nvarchar(50),
       marital_status nvarchar(50),
       pancard_details nvarchar(750),
       bank_details nvarchar(850),
       resume nvarchar(850)
);


  ALTER TABLE employee_registration
  DROP COLUMN pancard_details;
  
  
  ALTER TABLE employee_registration
  ADD pancard_details nvarchar(500);
  
   ALTER TABLE employee_registration
  DROP COLUMN bank_details;
  
  ALTER TABLE employee_registration
  ADD bank_details nvarchar(500);
  
   ALTER TABLE employee_registration
  DROP COLUMN resume;
  
    ALTER TABLE employee_registration
  ADD resume nvarchar(500);
  
    ALTER TABLE employee_registration
  modify applying_date nvarchar(90);
  
  
  
 
create table Admin_SignUp
 (
       user_id int primary key auto_increment,
       username nvarchar(50),
       email_id bigint(50),
       mobile_no bigint(50),
       password nvarchar(50),
       cpassword nvarchar(50),
	   date bigint(50)
 );
 
   ALTER TABLE admin_signup
  ADD designation nvarchar(50);  
  
  ALTER TABLE admin_signup
  ADD additional_details nvarchar(700);
  
  ALTER TABLE admin_signup
  DROP COLUMN additinal_details;
  
  ALTER TABLE admin_signup
  ADD address nvarchar(50);
  
   ALTER TABLE admin_signup
  modify email_id varchar(350);
  
  
    ALTER TABLE admin_attendence
  modify employee_id nvarchar(35);
 
 create table Admin_Attendence
 (
   user_id int primary key auto_increment,
   employee_id nvarchar(50),
   employeename nvarchar (50),
   email_id nvarchar (50),
   first_half nvarchar(100),
   second_half nvarchar(100),
   date nvarchar(50)
 );
 

  
   create table Admin_Remove
 (
  user_id int primary key auto_increment,
  employee_name nvarchar(50),
  employee_id nvarchar(50),
  email_id nvarchar(50),
  address nvarchar(50),
  mobile_no bigint(50),
  designation nvarchar(50),
  joining_date nvarchar(50),
  todays_date nvarchar(50)
  );
  
 create table Admin_Update
 (
  user_id int primary key auto_increment,
  employee_name nvarchar(50),
  employee_id nvarchar(50),
  email_id nvarchar(50),
  gender nvarchar(50),
  birth_date nvarchar(50),
  address nvarchar(50),
  mobile_no nvarchar(50),
  designation nvarchar(50),
  marital_status nvarchar(50),
  adhar_no nvarchar(50),
  joining_date nvarchar(50),
  todays_date nvarchar(50),
  profile_photo nvarchar(500),
  bank_details nvarchar(500)
  );
  
 ALTER TABLE admin_update
modify birth_date nvarchar(50);
 
  
   create table Employee_Issues
 (
  user_id int primary key auto_increment,
  employee_name nvarchar(50),
  employee_id nvarchar(50),
  email_id nvarchar(50),
  mobile_no nvarchar(50),
  subject nvarchar(50),
  description nvarchar(50),
  todays_date nvarchar(50),
  attachments nvarchar(500)
  );
  
  ALTER TABLE employee_issues
modify employee_id nvarchar(50);
 
  create table Employee_Leave
  (
  user_id int primary key auto_increment,
  employee_name nvarchar(50),
  employee_id nvarchar(50),
  start_day nvarchar(50),
  end_day nvarchar(50),
  requested_day nvarchar(50),
  designation nvarchar(50),
  leave_type nvarchar(50),
  leave_status nvarchar(50)
  );
  
  
  create table Employee_Salary
  (
  user_id int primary key auto_increment,
  employee_name nvarchar(50),
  employee_id nvarchar(50),
  email_id nvarchar(50),
  mobile_no nvarchar(50),
  designation nvarchar(50),
  department nvarchar(50),
  da nvarchar(50),
  hra nvarchar(50),
  mid nvarchar(50),
  pf nvarchar(50),
  prof_tax nvarchar(50),
  advance nvarchar(50),
  lic nvarchar(50),
  canteen nvarchar(50),
  total_period nvarchar(50),
  m_day nvarchar(50),
  bank_acc_no nvarchar(50),
  select_month nvarchar(50),
  select_year nvarchar(50),
  earning nvarchar(50),
  deduction nvarchar(50),
  net_pay nvarchar(50)
  );
  
  
  create table Password
  (
   user_id int primary key auto_increment,
   email_id nvarchar(50),
   password nvarchar(50),
   cpassword nvarchar(50)
  );
  
  
  create table Employee_Loan
  (
  loan_id int primary key auto_increment,
  employee_id nvarchar(50),
  employee_name varchar(50),
  email_id nvarchar(50),
  address nvarchar(50),
  mobile_no nvarchar(50),
  date_of_joining varchar(50),
  department nvarchar(50),
  designation nvarchar(50),
  required_date nvarchar(50),
  loan_type nvarchar(50),
  requested_amount nvarchar(50),
  bank_account_no nvarchar(50),
  installement_no nvarchar(50),
  mode_of_loan nvarchar(50),
  purpose_of_loan nvarchar(50),
  loan_details nvarchar(500),
  bank_details nvarchar(500),
  loan_status nvarchar(50)
  );
  
  create table Admin_Mails
 (
   user_id int primary key auto_increment,
   admin_email nvarchar(50),
   send_to nvarchar (60),
   department nvarchar(50),
   subject nvarchar(100),
   content nvarchar(500),
   file nvarchar(450)
 ); 
 
 
   create table Admin_Notice
 (
   user_id int primary key auto_increment,
   
   send_to nvarchar(50),
   department nvarchar(50),
   subject nvarchar(100),
   notice nvarchar(500),
   file nvarchar(450)
 ); 
 
  
   create table Admin_WorkManage
 (
   user_id int primary key auto_increment,
   admin_name nvarchar(50),
   task_name nvarchar(100),
   task_type nvarchar(100),
   due_date nvarchar(50),
   assignee nvarchar(50),
   task_category nvarchar(100),
   department nvarchar(50),
   priority nvarchar(50),
   instructions nvarchar(100),
   case_file nvarchar(500)
 ); 
 
 create table employees(
 
user_id int primary key auto_increment,
 title nvarchar(50),
 employees.lastname nvarchar(50),
 employees.name nvarchar(50),
 employees.city nvarchar(50)
 
 )