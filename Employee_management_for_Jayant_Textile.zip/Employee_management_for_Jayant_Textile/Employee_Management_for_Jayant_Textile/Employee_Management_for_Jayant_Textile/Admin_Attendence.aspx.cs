﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Employee_Management_for_Jayant_Textile
{
    public partial class Admin_Attendence : System.Web.UI.Page
    {
        MySqlConnection cn = new MySqlConnection("Server=localhost; Database=Employee_Management_for_Jayant_Textile; user=root; password=root");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataAdapter da = new MySqlDataAdapter();
        MySqlDataReader dr;


        protected void Page_Load(object sender, EventArgs e)
        {
          
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

           String employee_id = TextBox1.Text;
           String employeename = TextBox2.Text;
           String email_id = TextBox3.Text;
           String first_half = DropDownList1.SelectedValue;
           String second_half = DropDownList2.SelectedValue;
           String date = TextBox4.Text;

           try
           {
               cn.Close();
               cn.Open();
               String query = "insert into admin_attendence(employee_id, employeename, email_id, first_half, second_half, date) values ('" + employee_id + "', '" + employeename + "', '" + email_id + "', '" + first_half + "', '" + second_half + "', '" + date + "' )";
               cmd.Connection = cn;
               cmd.CommandText = query;
               int result = cmd.ExecuteNonQuery();

               Response.Write("<script type = 'text/javascript'> alert(' You Have Been Marked Present ');  </script>");

               cn.Close();
           }
           catch (Exception ex)
           {
               Response.Write(ex.ToString());
              Response.Write("<script type= 'text/javascript'> alert('You Have Been Market Absent');  </script>");


           }


        }
    }
}