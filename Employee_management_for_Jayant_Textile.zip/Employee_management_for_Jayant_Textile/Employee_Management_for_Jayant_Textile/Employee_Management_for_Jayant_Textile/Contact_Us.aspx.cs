﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Employee_Management_for_Jayant_Textile
{
    public partial class Contact_Us : System.Web.UI.Page
    {

        MySqlConnection cn = new MySqlConnection("Server=localhost; Database= Employee_Management_for_Jayant_Textile; user=root; password=root");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataAdapter da = new MySqlDataAdapter();
        MySqlDataReader dr;


        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            String name = TextBox1.Text;
            String email_id = TextBox2.Text;
            String subject = TextBox3.Text;
            String message = TextBox4.Text;
           

            try
            {
                cn.Close();
                cn.Open();
                String query = "insert into contact_us(name, email_id, subject, message) values ('" + name + "', '" + email_id + "', '" + subject + "', '" + message + "' )";
                cmd.Connection = cn;
                cmd.CommandText = query;
                int result = cmd.ExecuteNonQuery();

                Response.Write("<script type = 'text/javascript'> alert('We Thank You For Your Time Spent. Your Responce Has Been Recorded'); location='contact_us.aspx'; </script>");

                cn.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.ToString());
                //Response.Write("<script type= 'text/javascript'> alert('Ooops... Something Went Wrong. No Worries You Can Try One More Time.'); location= 'contact_us.aspx'; </script>");


            }

        }
    }
}