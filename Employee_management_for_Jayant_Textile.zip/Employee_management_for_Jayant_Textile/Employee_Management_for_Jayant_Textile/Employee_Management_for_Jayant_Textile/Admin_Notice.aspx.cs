﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Employee_Management_for_Jayant_Textile
{
    public partial class Admin_Notice : System.Web.UI.Page
    {

        MySqlConnection cn = new MySqlConnection("Server=localhost; Database=Employee_Management_for_Jayant_Textile; user=root; password=root");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataAdapter da = new MySqlDataAdapter();
        MySqlDataReader dr;




        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {


            String send_to = DropDownList1.SelectedValue;
            String department = TextBox3.Text;
            String subject = TextBox4.Text;
            String notice = TextBox5.Text;
            String file = FileUpload1.FileName;


            try
            {
                cn.Close();
                cn.Open();
                String query = "insert into admin_notice( send_to, department, subject, notice, file) values ('" + send_to + "', '" + department + "', '" + subject + "', '" + notice + "', '" + file + "')";
                cmd.Connection = cn;
                cmd.CommandText = query;
                int result = cmd.ExecuteNonQuery();

                Response.Write("<script type = 'text/javascript'> alert('Your Notice Has Been Sent.'); location='Admin_Notice.aspx'; </script>");

                cn.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.ToString());
                Response.Write("<script type= 'text/javascript'> alert('oh no, you are failed to send message.'); </script>");


            }



        }
    }
}