﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Employee_Management_for_Jayant_Textile
{
    public partial class WebForm2 : System.Web.UI.Page
    {


        MySqlConnection cn = new MySqlConnection("Server=localhost; Database=Employee_Management_for_Jayant_Textile; user=root; password=root");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataAdapter da = new MySqlDataAdapter();
        MySqlDataReader dr;

        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void ButtonSearch_Click(object sender, EventArgs e)
        {
           
            }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Button b1 = (Button)sender;
            GridViewRow item = (GridViewRow)b1.NamingContainer;

            HiddenField h1 = (HiddenField)item.FindControl("HiddenField1");
            Session["user_id"] = h1.Value.ToString();
             
            HiddenField h2 = (HiddenField)item.FindControl("HiddenField2");
            Session["employee_name"] = h2.Value.ToString();
 

            HiddenField h3 = (HiddenField)item.FindControl("HiddenField3");
            Session["employee_id"] = h3.Value.ToString();
             

            HiddenField h4 = (HiddenField)item.FindControl("HiddenField4");
            Session["date_of_birth"] = h4.Value.ToString();
             

            HiddenField h5 = (HiddenField)item.FindControl("HiddenField5");
            Session["email_id"] = h5.Value.ToString();

            HiddenField h6 = (HiddenField)item.FindControl("HiddenField6");
            Session["mobile_no"] = h6.Value.ToString();
            
            HiddenField h7 = (HiddenField)item.FindControl("HiddenField6");
            Session["gender"] = h7.Value.ToString();
             

            HiddenField h8 = (HiddenField)item.FindControl("HiddenField7");
            Session["address"] = h8.Value.ToString();
             

            HiddenField h9 = (HiddenField)item.FindControl("HiddenField8");
            Session["highest_qualification"] = h9.Value.ToString();
             
            HiddenField h10 = (HiddenField)item.FindControl("HiddenField9");
            Session["designation"] = h10.Value.ToString();
             

            HiddenField h11 = (HiddenField)item.FindControl("HiddenField10");
            Session["adhar_no"] = h11.Value.ToString();
             

            HiddenField h12 = (HiddenField)item.FindControl("HiddenField11");
            Session["voting_no"] = h12.Value.ToString();
             

            HiddenField h13 = (HiddenField)item.FindControl("HiddenField12");
            Session["password"] = h13.Value.ToString();
             

            HiddenField h14 = (HiddenField)item.FindControl("HiddenField13");
            Session["cpassword"] = h14.Value.ToString();
             

            HiddenField h15 = (HiddenField)item.FindControl("HiddenField14");
            Session["applying_date"] = h15.Value.ToString();
             

            HiddenField h16 = (HiddenField)item.FindControl("HiddenField15");
            Session["type_of_work"] = h16.Value.ToString();
             

            HiddenField h17 = (HiddenField)item.FindControl("HiddenField16");
            Session["languages_spoken"] = h17.Value.ToString();
             

            HiddenField h18 = (HiddenField)item.FindControl("HiddenField17");
            Session["marital_status"] = h18.Value.ToString();
             

            HiddenField h19 = (HiddenField)item.FindControl("HiddenField1");
            Session["pancard_details"] = h19.Value.ToString();
             

            HiddenField h20 = (HiddenField)item.FindControl("HiddenField1");
            Session["bank_details"] = h20.Value.ToString();
             

            HiddenField h21 = (HiddenField)item.FindControl("HiddenField21");
            Session["resume"] = h21.Value.ToString();


            Response.Redirect("View.aspx");


        }
        }
    }