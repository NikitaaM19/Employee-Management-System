﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Employee_Management_for_Jayant_Textile
{
    public partial class Second : System.Web.UI.Page
    {
        MySqlConnection cn = new MySqlConnection("Server=localhost; Database=Employee_Management_for_Jayant_Textile; user=root; password=root");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataAdapter da = new MySqlDataAdapter();
        MySqlDataReader dr;


        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            Response.Write("<script type = 'text/javascript'> location='Admin_Login.aspx'; </script>");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {

            Response.Write("<script type = 'text/javascript'> location='Employee_Login.aspx'; </script>");
        }

        protected void Button3_Click(object sender, EventArgs e)
        {

            Response.Write("<script type = 'text/javascript'> location='Admin_SignUp.aspx'; </script>");
        }

        protected void Button4_Click(object sender, EventArgs e)
        {

            Response.Write("<script type = 'text/javascript'> location='Employee_Registration.aspx'; </script>");
        }
    }
}