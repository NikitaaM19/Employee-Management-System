﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Employee_Management_for_Jayant_Textile
{
    public partial class Admin_SignUp : System.Web.UI.Page
    {
        MySqlConnection cn = new MySqlConnection("Server=localhost; Database=Employee_Management_for_Jayant_Textile; user=root; password=root");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataAdapter da = new MySqlDataAdapter();
        MySqlDataReader dr;


        protected void Page_Load(object sender, EventArgs e)
        {
          
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            String username = TextBox2.Text;
            String email_id = TextBox3.Text;
            String mobile_no = TextBox6.Text;
            String password = TextBox4.Text;
            String cpassword = TextBox8.Text;
            String date = TextBox9.Text;
            String designation = TextBox5.Text;
            String address = TextBox1.Text;
            String additional_details = FileUpload1.FileName;


            try
            {
                cn.Close();
                cn.Open();
                String query = "insert into admin_signup(username, email_id, mobile_no, password, cpassword, date, designation, address, additional_details) values ('" + username + "', '"+email_id+"', '"+mobile_no+"', '"+password+"', '"+cpassword+"', '"+date+"', '"+designation+"', '"+address+"', '"+additional_details+"' )";
                cmd.Connection = cn;
                cmd.CommandText = query;
                int result = cmd.ExecuteNonQuery();

                Response.Write("<script type = 'text/javascript'> alert('We Are Delighted To Inform You That You Are Now Member Of Our Family'); location='admin_login.aspx'; </script>");

                cn.Close();
            }
            catch (Exception ex)
            {
            Response.Write(ex.ToString());
            Response.Write("<script type= 'text/javascript'> alert('Ooops... Something Went Wrong. No Worries You Can Try One More Time.'); location= 'admin_signup.aspx'; </script>");
            
            
            }

        }

       
    }
}