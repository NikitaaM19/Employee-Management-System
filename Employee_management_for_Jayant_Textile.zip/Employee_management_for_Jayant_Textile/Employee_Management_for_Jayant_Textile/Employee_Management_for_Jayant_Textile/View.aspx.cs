﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Employee_Management_for_Jayant_Textile
{
    public partial class View : System.Web.UI.Page
    {

        MySqlConnection cn = new MySqlConnection("Server=localhost; Database=Employee_Management_for_Jayant_Textile; user=root; password=root");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataAdapter da = new MySqlDataAdapter();
        MySqlDataReader dr;

        protected void Page_Load(object sender, EventArgs e)
        {
            Label1.Text = Session["user_id"].ToString();
            Label2.Text = Session["employee_name"].ToString();
            Label3.Text = Session["employee_id"].ToString();
            Label4.Text = Session["date_of_birth"].ToString();
            Label5.Text = Session["email_id"].ToString();
            Label6.Text = Session["mobile_no"].ToString();
            Label7.Text = Session["gender"].ToString();
            Label8.Text = Session["address"].ToString();
            Label9.Text = Session["highest_qualification"].ToString();
            Label10.Text = Session["designation"].ToString();
            Label11.Text = Session["adhar_no"].ToString();
            Label12.Text = Session["voting_no"].ToString();
            Label13.Text = Session["password"].ToString();
            Label14.Text = Session["cpassword"].ToString();
            Label15.Text = Session["applying_date"].ToString();
            Label16.Text = Session["type_of_work"].ToString();
            Label17.Text = Session["languages_spoken"].ToString();
            Label18.Text = Session["marital_status"].ToString();
            Label19.Text = Session["pancard_details"].ToString();
            Label20.Text = Session["bank_details"].ToString();
            Label21.Text = Session["resume"].ToString();
           
        }

        protected void Button1_Click(object sender, EventArgs e)
        {


            String f = Session["resume"].ToString(); 
             
            try
            {

                Response.ContentType = "application/pdf";
                Response.AppendHeader("Content-Disposition", "attachment; filename=" + f + " ");
                Response.TransmitFile(Server.MapPath("~/images/"+f));
                Response.End();
            }
            catch (Exception ex)
            {
                Response.Write(ex.ToString());
            }  
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            String f = Session["pancard_details"].ToString();

            try
            {

                Response.ContentType = "application/pdf";
                Response.AppendHeader("Content-Disposition", "attachment; filename=" + f + " ");
                Response.TransmitFile(Server.MapPath("~/images/" + f));
                Response.End();
            }
            catch (Exception ex)
            {
                Response.Write(ex.ToString());
            }  
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            String f = Session["bank_details"].ToString();

            try
            {

                Response.ContentType = "application/pdf";
                Response.AppendHeader("Content-Disposition", "attachment; filename=" + f + " ");
                Response.TransmitFile(Server.MapPath("~/images/" + f));
                Response.End();
            }
            catch (Exception ex)
            {
                Response.Write(ex.ToString());
            }  
        }
    }
}