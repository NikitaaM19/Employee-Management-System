﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Employee_Management_for_Jayant_Textile
{
    public partial class Employee_Leave : System.Web.UI.Page
    {

        MySqlConnection cn = new MySqlConnection("Server=localhost; Database=Employee_Management_for_Jayant_Textile; user=root; password=root");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataAdapter da = new MySqlDataAdapter();
        MySqlDataReader dr;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            String employee_name = TextBox1.Text;
            String employee_id = TextBox2.Text;
            String start_day = TextBox3.Text;
            String end_day = TextBox4.Text;
            String requested_day = DropDownList1.SelectedValue;
            String designation = TextBox5.Text;
            String leave_type = DropDownList2.SelectedValue;
            try
            {
                cn.Close();
                cn.Open();
                String query = "insert into employee_leave( employee_name, employee_id, start_day, end_day, requested_day, designation, leave_type) values ( '" + employee_name + "', '" + employee_id + "', '" + start_day + "', '" + end_day + "', '" + requested_day + "', '" + designation + "',  '" + leave_type + "' )";
                cmd.Connection = cn;
                cmd.CommandText = query;
                int result = cmd.ExecuteNonQuery();

                Response.Write("<script type = 'text/javascript'> alert('Please Wait For Admins Approval'); </script>");

                cn.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.ToString());
                Response.Write("<script type= 'text/javascript'> alert('Oh No, Something Went Wrong'); </script>");


            }

      
        
        }

    }
}