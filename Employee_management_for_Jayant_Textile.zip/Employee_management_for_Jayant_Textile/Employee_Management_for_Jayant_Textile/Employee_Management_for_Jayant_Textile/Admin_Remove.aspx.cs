﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Employee_Management_for_Jayant_Textile
{
    public partial class Admin_Remove : System.Web.UI.Page
    {
        MySqlConnection cn = new MySqlConnection("Server=localhost; Database=Employee_Management_for_Jayant_Textile; user=root; password=root");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataAdapter da = new MySqlDataAdapter();
        MySqlDataReader dr;


        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            String employee_name = TextBox1.Text;
            String employee_id = TextBox2.Text;
            String email_id = TextBox3.Text;
            String address = TextBox4.Text;
            String mobile_no = TextBox5.Text;
            String designation = TextBox6.Text;
            String joining_date = TextBox7.Text;
            String todays_date = TextBox8.Text;


            try
            {
                cn.Close();
                cn.Open();
                String query = "delete from employee_registration where employee_id ='" + employee_id +"' ";
                cmd.Connection = cn;
                cmd.CommandText = query;
                int result = cmd.ExecuteNonQuery();
                Response.Write("<Script type='text/javascript'> alert('Employee Has Been Deleted'); location='Admin_Remove.aspx'</Script>");
                cn.Close();
            }

            catch (Exception ex)
            {
                Response.Write(ex.ToString());
                Response.Write("<Script type='text/javascript'> alert('Something Went Wrong'); location='Admin_Remove.aspx'</Script>");

            }



        }
    }
}