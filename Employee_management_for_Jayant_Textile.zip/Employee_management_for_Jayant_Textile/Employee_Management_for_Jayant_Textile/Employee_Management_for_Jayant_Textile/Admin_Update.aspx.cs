﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Employee_Management_for_Jayant_Textile
{
    public partial class Admin_Update : System.Web.UI.Page
    {
        MySqlConnection cn = new MySqlConnection("Server=localhost; Database=Employee_Management_for_Jayant_Textile; user=root; password=root");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataAdapter da = new MySqlDataAdapter();
        MySqlDataReader dr;


        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            String employee_name = TextBox1.Text;
            String employee_id = TextBox2.Text;
            String email_id = TextBox3.Text;
            String gender = DropDownList1.SelectedValue;
            String birth_date = TextBox5.Text;
            String address = TextBox6.Text;
            String mobile_no = TextBox7.Text;
            String designation = TextBox8.Text;
            String marital_status = TextBox9.Text;
            String adhar_no = TextBox10.Text;
            String joining_date = TextBox11.Text;
            String type_of_work = TextBox12.Text;
            String pancard_details = FileUpload1.FileName;
            String bank_details = FileUpload2.FileName;

            try
            {
                cn.Close();
                cn.Open();
                String query = "update employee_registration set employee_name='" + employee_name + "', employee_id='" + employee_id + "', email_id='" + email_id + "', gender='" + gender + "', date_of_birth= '" + birth_date + "', address='" + address + "', mobile_no='" + mobile_no + "', designation='" + designation + "', marital_status='" + marital_status + "', adhar_no='" + adhar_no + "', applying_date= '" + joining_date + "',type_of_work= '" + type_of_work + "',  pancard_details='" + pancard_details + "',bank_details='" + bank_details + "' where employee_id = '" + employee_id + "' ";
                cmd.Connection = cn;
                cmd.CommandText = query;
                int result = cmd.ExecuteNonQuery();

                Response.Write("<Script type='text/javascript'> alert('Employee Details Has Been Updated'); location='Admin_Update.aspx'; </Script>");
                
                cn.Close();
            }

            catch (Exception ex)
            {
                Response.Write(ex.ToString());
                Response.Write("<Script type='text/javascript'> alert('Oh No, You Are Failed In Update'); </Script>");
            
            }

        }
    }
}