﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Employee_Management_for_Jayant_Textile
{
    public partial class Admin_Menu : System.Web.UI.Page
    {

        MySqlConnection cn = new MySqlConnection("Server=localhost; Database=Employee_Management_for_Jayant_Textile; user=root; password=root");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataAdapter da = new MySqlDataAdapter();
        MySqlDataReader dr;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Write("<script type = 'text/javascript'> location= 'Admin_Mails.aspx' </script>");
               
        }

        protected void Button4_Click(object sender, EventArgs e)
        {

            Response.Write("<script type = 'text/javascript'> location= 'admin_notice.aspx' </script>");
        }

        protected void Button5_Click(object sender, EventArgs e)
        {

            Response.Write("<script type = 'text/javascript'> location= 'employee_salary.aspx' </script>");
        }

        protected void Button9_Click(object sender, EventArgs e)
        {

            Response.Write("<script type = 'text/javascript'> location= 'admin_remove.aspx' </script>");
        }

        protected void Button10_Click(object sender, EventArgs e)
        {
            Response.Write("<script type = 'text/javascript'> location= 'admin_update.aspx' </script>");

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            Response.Write("<script type = 'text/javascript'> location= 'admin_attendence.aspx' </script>");

        }

        protected void Button2_Click(object sender, EventArgs e)
        {

            Response.Write("<script type = 'text/javascript'> location= 'admin_workmanage.aspx' </script>");

        }

        protected void Button6_Click(object sender, EventArgs e)
        {

            Response.Write("<script type = 'text/javascript'> location= 'loan_details.aspx' </script>");

        }

        protected void Button11_Click(object sender, EventArgs e)
        {
            Response.Write("<script type = 'text/javascript'> location= 'Admin_Issues.aspx' </script>");

        }

        protected void Button12_Click(object sender, EventArgs e)
        {
            Response.Write("<script type = 'text/javascript'> location= 'admin_leave_approval.aspx' </script>");

        }

        protected void Button13_Click(object sender, EventArgs e)
        {
            Response.Write("<script type = 'text/javascript'> location= 'admin_attendence_details.aspx' </script>");

        }

        protected void Button8_Click(object sender, EventArgs e)
        {
            Response.Write("<script type = 'text/javascript'> location= 'admin_review_details.aspx' </script>");

        }
    }

}