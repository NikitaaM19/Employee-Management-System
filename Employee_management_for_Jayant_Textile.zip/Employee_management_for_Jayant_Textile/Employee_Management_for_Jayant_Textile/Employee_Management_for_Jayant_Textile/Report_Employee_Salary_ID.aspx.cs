﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using CrystalDecisions.CrystalReports.Engine;
using MySql.Data.MySqlClient;
namespace Employee_Management_for_Jayant_Textile
{
    public partial class Report_Employee_Salary_ID : System.Web.UI.Page
    {
        MySqlConnection cn = new MySqlConnection("Server=localhost; Database=Employee_Management_for_Jayant_Textile; user=root; password=root");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataAdapter da = new MySqlDataAdapter();
        MySqlDataReader dr;
        ReportDocument rprt = new ReportDocument();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            rprt.Load(Server.MapPath("~/rpt_Report_Employee_Salary.rpt"));
            MySqlConnection cn = new MySqlConnection("Server=localhost; Database=Employee_Management_for_Jayant_Textile; user=root; password=root");
            MySqlCommand cmd = new MySqlCommand("select * from employee_salary where employee_id = '" + TextBox1.Text + "'", cn);
            MySqlDataAdapter sda = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            rprt.SetDataSource(dt);
            CrystalReportViewer1.ReportSource = rprt;
            CrystalReportViewer1.DataBind();
        }

       
    }
}