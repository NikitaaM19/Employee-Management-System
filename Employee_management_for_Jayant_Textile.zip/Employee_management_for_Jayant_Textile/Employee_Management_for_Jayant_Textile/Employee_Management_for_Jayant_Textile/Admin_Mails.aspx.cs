﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Employee_Management_for_Jayant_Textile
{
    public partial class Admin_Mails : System.Web.UI.Page
    {

        MySqlConnection cn = new MySqlConnection("Server=localhost; Database=Employee_Management_for_Jayant_Textile; user=root; password=root");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataAdapter da = new MySqlDataAdapter();
        MySqlDataReader dr;




        protected void Page_Load(object sender, EventArgs e)
        {
          

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
              String admin_email = TextBox1.Text;
              String send_to = DropDownList1.SelectedValue;
              String department = TextBox3.Text;
              String subject = TextBox4.Text;
              String content = TextBox5.Text;
              String file = FileUpload1.FileName;
             
            
            try
              {
                  cn.Close();
                  cn.Open();
                  String query = "insert into admin_mails( admin_email, send_to, department, subject, content, file) values ( '" + admin_email + "', '" + send_to + "', '" + department + "', '" + subject + "', '" + content + "', '" + file + "')";
                  cmd.Connection = cn;
                  cmd.CommandText = query;
                  int result = cmd.ExecuteNonQuery();

                  Response.Write("<script type = 'text/javascript'> alert('You Are Mail Have Been Delivered '); location='Admin_Mails.aspx'; </script>");

                  cn.Close();
              }
              catch (Exception ex)
              {
                  Response.Write(ex.ToString());
                  Response.Write("<script type= 'text/javascript'> alert('Sorry! Mail Delivery Failed'); location= 'admin_signup.aspx'; </script>");


              }



        }
    }
}