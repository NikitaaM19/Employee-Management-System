﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Employee_Management_for_Jayant_Textile
{
    public partial class Employee_Loan : System.Web.UI.Page
    {

        MySqlConnection cn = new MySqlConnection("Server=localhost; Database=Employee_Management_for_Jayant_Textile; user=root; password=root");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataAdapter da = new MySqlDataAdapter();
        MySqlDataReader dr;


        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            String employee_id = TextBox1.Text;
            String employee_name = TextBox2.Text;
            String email_id = TextBox3.Text;
            String address = TextBox4.Text;
            String mobile_no = TextBox5.Text;
            String date_of_joining = TextBox6.Text;
            String department = TextBox7.Text;
            String designation = TextBox8.Text;
            String required_date = TextBox9.Text;
            String loan_type = DropDownList1.SelectedValue;
            String requested_amount = TextBox10.Text;
            String bank_account_no = TextBox11.Text;
            String installement_no = TextBox12.Text;
            String mode_of_loan = TextBox13.Text;
            String purpose_of_loan = TextBox14.Text;
            String loan_details = FileUpload1.FileName;
            String bank_details = FileUpload2.FileName;
            try
            {
                cn.Close();
                cn.Open();
                String query = "insert into employee_loan(employee_id, employee_name, email_id, address, mobile_no, date_of_joining, department, designation, required_date, loan_type, requested_amount, bank_account_no, installement_no, mode_of_loan, purpose_of_loan, loan_details, bank_details) values ('" + employee_id + "', '" + employee_name + "', '" + email_id + "', '" + address + "', '" + mobile_no + "', '" + date_of_joining + "', '" + department + "', '" + designation + "', '"+ required_date+"', '"+loan_type+"', '" + requested_amount + "', '"+ bank_account_no +"', '"+ installement_no +"', '"+ mode_of_loan+"', '"+ purpose_of_loan +"', '"+ loan_details +"', '"+ bank_details +"' )";
                cmd.Connection = cn;
                cmd.CommandText = query;
                int result = cmd.ExecuteNonQuery();

                Response.Write("<script type = 'text/javascript'> alert('You Are Eligible To Get Loan');  </script>");

                cn.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.ToString());
                Response.Write("<script type= 'text/javascript'> alert(' Sorry! According To Our Terms Ands Conditions Your Not Eligible To Get Loan'); </script>");


            }
 
        }

    

    }
}