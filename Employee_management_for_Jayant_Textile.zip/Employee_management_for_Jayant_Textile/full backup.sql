-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: employee_management_for_jayant_textile
-- ------------------------------------------------------
-- Server version	5.7.10-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_attendence`
--

DROP TABLE IF EXISTS `admin_attendence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_attendence` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` varchar(50) DEFAULT NULL,
  `employeename` varchar(50) DEFAULT NULL,
  `email_id` varchar(50) DEFAULT NULL,
  `first_half` varchar(100) DEFAULT NULL,
  `second_half` varchar(100) DEFAULT NULL,
  `date` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_attendence`
--

LOCK TABLES `admin_attendence` WRITE;
/*!40000 ALTER TABLE `admin_attendence` DISABLE KEYS */;
INSERT INTO `admin_attendence` VALUES (1,'1','Nikita Mane','nikita@gmail.com','Adsent','Present','21-02-2024'),(2,'2','Pranoti Salunkhe','pranoti@gmail.com','Present','Absent','21-2-2024'),(3,'3','Aditi Patil','aditi@gmail.com','Present','Absent','21-2-2024'),(4,'4','Pranali Thorat','pranali@gmail.com','Present','Absent','21-2-2024'),(5,'5',' Dhanashri Thorat','dhana@gmail.com','Present','Present','06-03-2024'),(6,'6','Anushaka  Patil','anu@gmail.com','Absent','Present','06-03-2024'),(7,'7','Siya','siya@gmail.com','Present','Present','07-03-2024'),(8,'8','Ganesh','ganesh@gmail.com','Absent','Absent','07-03-2024'),(9,'9','Sarvesh Thorat','sarvesh@gmail.com','present','present','09-03-2024'),(10,'10','Shri ','shri','absent','present','10-03-2024'),(11,'1','Nikita','nikita@gmail.com','Absent','Absent','17-04-2024');
/*!40000 ALTER TABLE `admin_attendence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_mails`
--

DROP TABLE IF EXISTS `admin_mails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_mails` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_email` varchar(50) DEFAULT NULL,
  `send_to` varchar(60) DEFAULT NULL,
  `department` varchar(50) DEFAULT NULL,
  `subject` varchar(100) DEFAULT NULL,
  `content` varchar(500) DEFAULT NULL,
  `file` varchar(450) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_mails`
--

LOCK TABLES `admin_mails` WRITE;
/*!40000 ALTER TABLE `admin_mails` DISABLE KEYS */;
INSERT INTO `admin_mails` VALUES (1,'manoj@gmail.com','Send To All','Marketing','Urgent Meeting','We are conducting An Urgent meeting .','Doc11.docx'),(2,'sakshi@gmail.com','To All Employees','Sells','Office Work','We are ','Doc11.docx'),(3,'prajkta@gmail.com','Selected Users','HR','Leave Notice','Leave From 12 March to 17 March','Doc11.docx'),(4,'ankita@gmail.com','Choose Receiver','Manufacturing','Holidays','Announcement of Holidays','Doc11.docx'),(5,'Anushka Patil','To All Employees','Security','Urgent Work','Working ','Doc11.docx'),(6,'manjali@gmail.com','To All Employees','Maufacturing','Festivals','Mails Related To Festivals','Doc11.docx'),(7,'nikita@gmail.com','Selected Users','Sells','Tasks','Working States','Doc11.docx'),(8,'swara@gmail.com','To All  Employess','Tax','Health','Health Campaign','Doc11.docx'),(9,'adhavet@gmail.com','Selected Users','Manufacturing','Update','Employee Update','Doc11.docx'),(10,'mohini@gmail.com','To All  Employees','HR','Mail Security','Mail Security Alert','Doc11.docx'),(11,'','Choose Receiver','','','Leave','');
/*!40000 ALTER TABLE `admin_mails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_notice`
--

DROP TABLE IF EXISTS `admin_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_notice` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `send_to` varchar(50) DEFAULT NULL,
  `department` varchar(50) DEFAULT NULL,
  `subject` varchar(100) DEFAULT NULL,
  `notice` varchar(500) DEFAULT NULL,
  `file` varchar(450) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_notice`
--

LOCK TABLES `admin_notice` WRITE;
/*!40000 ALTER TABLE `admin_notice` DISABLE KEYS */;
INSERT INTO `admin_notice` VALUES (1,'Choose Receiver','Sells','Essentials','This notice is to inform you in advance that our office will be closed from 10-2-2024 to 12-2-2024','Doc11.docx'),(2,'Selected Users','HR','Leave Notice','Leave','Doc11.docx'),(3,'All users from selected role','Developing','Salary increment','Good New for all the employees youir salary has been incremented from now.','Doc11.docx'),(4,'Selected Users','Manufacturing','Product Delivery','We have to finish our task before the deadlines.','Doc11.docx'),(5,'All users from selected role','Security','Festival Related','Festivals','Doc11.docx'),(6,'Selected Users','Developing','Preview','Employee Preview','Doc11.docx'),(7,'All users from selected role','HR','Attendence','Tracking In Minutes','Doc11.docx'),(8,'Selected Users','Manufacturing','Alert','New Holiday Alert','Doc11.docx'),(9,'All users from selected role','Sells','A Friendly Remainder','Important Meeting Tomorrow','Doc11.docx'),(10,'Selected Users','Manufacturing','Overtime','March Overtime Payroll','Doc11.docx'),(11,'Choose Receiver','HR','Leave Notice','Leave',''),(12,'Choose Receiver','','','Leave','');
/*!40000 ALTER TABLE `admin_notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_remove`
--

DROP TABLE IF EXISTS `admin_remove`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_remove` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_name` varchar(50) DEFAULT NULL,
  `employee_id` varchar(50) DEFAULT NULL,
  `email_id` varchar(50) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `mobile_no` bigint(50) DEFAULT NULL,
  `designation` varchar(50) DEFAULT NULL,
  `joining_date` varchar(50) DEFAULT NULL,
  `todays_date` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_remove`
--

LOCK TABLES `admin_remove` WRITE;
/*!40000 ALTER TABLE `admin_remove` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_remove` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_signup`
--

DROP TABLE IF EXISTS `admin_signup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_signup` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `email_id` varchar(350) DEFAULT NULL,
  `mobile_no` bigint(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `cpassword` varchar(50) DEFAULT NULL,
  `date` varchar(35) DEFAULT NULL,
  `designation` varchar(50) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `additional_details` varchar(700) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_signup`
--

LOCK TABLES `admin_signup` WRITE;
/*!40000 ALTER TABLE `admin_signup` DISABLE KEYS */;
INSERT INTO `admin_signup` VALUES (1,'Nikita ','nikita@gmail.com',987654321,'1','1','2023-02-02','Sells Manager','Walwa','Doc1-1.docx'),(2,'Swara Salunkhe','Swara@gmail.com',1234567780,'2305','2305','2023-06-02','IT Manager','Walwa','Doc11.docx'),(3,'Adhavet Mane','adhavet@gmail.com',6789054321,'1902','1902','2024-01-03','Manucturing Manager','Walwa','Doc11.docx'),(4,'Manjali','manjali@gmail.com',978654321,'0312','0312','2024-01-03','Manager','Walwa','Doc11.docx'),(5,'Mohini Patil','mohini@gmail.com',9988776655,'1234','1234','2024-01-02','Manager','Walwa','Doc1-1.docx'),(6,'Pratham Thorat','pratham@gmail.com',9987766559,'1111','1111','2024-01-02','Security','Islampur','Doc11.docx'),(7,'Manoj ','manoj@gmail.com',9876543322,'2222','2222','2024-02-02','Development','Islampur','Doc11.docx'),(8,'Prajkta Patil','prajkta@gmail.com',1234567890,'3333','3333','2024-03-02','C.A.','Sangli','Doc11.docx'),(9,'Swapnali Mali','swapnali@gmail.com',9076543213,'4444','4444','2024-04-02','Manager','Walwa','Doc11.docx'),(10,'Sakshi Sutar','sakshi@gmail.com',8906543221,'0909','0909','2024-04-02','Manager','Walwa','Doc11.docx'),(11,'1','1',987654321,'1','1','2024-03-15','Manager','Walwa','');
/*!40000 ALTER TABLE `admin_signup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_workmanage`
--

DROP TABLE IF EXISTS `admin_workmanage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_workmanage` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(50) DEFAULT NULL,
  `task_name` varchar(100) DEFAULT NULL,
  `task_type` varchar(100) DEFAULT NULL,
  `due_date` varchar(50) DEFAULT NULL,
  `assignee` varchar(50) DEFAULT NULL,
  `task_category` varchar(100) DEFAULT NULL,
  `department` varchar(50) DEFAULT NULL,
  `priority` varchar(50) DEFAULT NULL,
  `instructions` varchar(100) DEFAULT NULL,
  `task_status` varchar(60) DEFAULT NULL,
  `case_file` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_workmanage`
--

LOCK TABLES `admin_workmanage` WRITE;
/*!40000 ALTER TABLE `admin_workmanage` DISABLE KEYS */;
INSERT INTO `admin_workmanage` VALUES (1,'Nikita','Selling ','Selling Products','19-03-2024','Nikita Mane','Selling Maximum Products','Sells and Tax','Normal','Products are Sold Before The Due Date','Task Completed','Doc11.docx'),(2,'Sakshi Sutar','Manufacturing','Manufacturing','20-03-2024','Pranoti','Manufacture','Manufacturing Cloths','Normal','Manufacturing Designer Cloths','Not Completed','Doc11.docx'),(3,'Manoj ','Security','Security','21-03-2024','Ankita Patil','Security','Security','Urgent','Security','Task Completed','Doc11.docx'),(4,'Nikita','Margeting','Marketing','22-03-2024','Pranali Patil','Marketing','Marketing','Normal','Marketing Products','Not Completed','Doc11.docx'),(5,'Pratham Thorat','Devloping','Devloping','23-03-2024','Anushka Patil','Devloping','Devlopment','Urgent','Devloping Products','Task Completed','Doc11.docx'),(6,'Nikita','Devloping','Devloping','24-03-2024','Siya','Devloping','Devloping','Regular','Devloping','Not Completed','Doc11.docx'),(7,'Mohini Patil','Margeting','Margeting','24-03-2024','Dhanashri ','Margeting','Marketing','Urgent','Marketing goods','Not Completed','Doc11.docx'),(8,'Adhavet Mane','Devloping','Devloping','25-03-2024','Sarvesh Desai','Devloping','Devloping','Normal','Devloping','Task Completed','Doc11.docx'),(9,'Swara Salunkhe','Manufacturing','Manufacturing','25-03-2024','Shri','Manufacturing','Manufacturing','Urgent','Manufacturing',NULL,'Doc11.docx'),(10,'Nikita','Manufacturing','Manufacturing','26-03-2024','Ganesh','Manufacturing','Manufacturing','Regular','Manufacturing',NULL,'Doc11.docx'),(11,'','','','','','','','Normal','',NULL,'');
/*!40000 ALTER TABLE `admin_workmanage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact_us`
--

DROP TABLE IF EXISTS `contact_us`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_us` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `email_id` varchar(50) DEFAULT NULL,
  `subject` varchar(100) DEFAULT NULL,
  `message` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact_us`
--

LOCK TABLES `contact_us` WRITE;
/*!40000 ALTER TABLE `contact_us` DISABLE KEYS */;
INSERT INTO `contact_us` VALUES (1,'Nikita ','nikita@gmail.com','Review','Review'),(2,'Ram','ram@gmail.com','Contact','Contact'),(3,'Siya','siya@gmail.com','Feedback','Feedback'),(4,'Abhishek Malhan','abhi@gmail.com','Review','Review'),(5,'Pranoti Salunkhe','aditi@gmail.com','Feedback','Feedback'),(6,'Sakshi Sutar','sakshi@gmail.com','Feedback','Feedback'),(7,'Harsh Patil','harsh@gmail.com','Review','Review'),(8,'Kishori Jadhav','kishori@gmail.com','Review','Review'),(9,'Nikhil Chavan','nikhil@gmail.com','Review','Review'),(10,'Ankita Patil','ankita@gmail.com','Feedback','Feedback');
/*!40000 ALTER TABLE `contact_us` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_issues`
--

DROP TABLE IF EXISTS `employee_issues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee_issues` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_name` varchar(50) DEFAULT NULL,
  `employee_id` varchar(50) DEFAULT NULL,
  `email_id` varchar(50) DEFAULT NULL,
  `mobile_no` varchar(50) DEFAULT NULL,
  `subject` varchar(50) DEFAULT NULL,
  `description` varchar(50) DEFAULT NULL,
  `todays_date` varchar(50) DEFAULT NULL,
  `attachments` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_issues`
--

LOCK TABLES `employee_issues` WRITE;
/*!40000 ALTER TABLE `employee_issues` DISABLE KEYS */;
INSERT INTO `employee_issues` VALUES (1,'Nikita Mane','1','nikita123@gmail.com','1234567890','Leave','Leave','02-02-2024','Doc11.docx'),(2,'Pranoti Salunkhe','2','pranoti@gmail.com','9876543210','Health','Health Resources','10-02-2024','Doc11.docx'),(3,'Ankita Patil','3','ankita@gmail.com','6789054321','Safety','Cyber Security','17-02-2024','Doc11.docx'),(4,'Pranali Patil','4','pranali@gmail.com','1234098765','Traning','Traning','23-02-2024','Doc11.docx'),(5,'Anushka Patil','5','anushka@gmail.com','2314567890','Leave','Leave','27-02-2024','Doc11.docx'),(6,'Siya','6','siya@gmail.com','9087564321','Health','Health','01-03-2024','Doc11.docx'),(7,'Dhanashri Thorat','7','dhanu@gmail.com','9087564321','Leave','Leave','05-03-2024','Doc11.docx'),(8,'Saevesh Desai','8','sarvesh@gmail.com','5673910274','Health','Health','09-03-2024','Doc11.docx'),(9,'Shri ','9','shri@gmail.com','7689034657','Leave','Leave','10-03-2024','Doc11.docx'),(10,'Ganesh','10','ganesh@gmail.com','9067834521','Training','Training','11-03-2024','Doc11.docx'),(11,'','','','','','','','');
/*!40000 ALTER TABLE `employee_issues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_leave`
--

DROP TABLE IF EXISTS `employee_leave`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee_leave` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_name` varchar(50) DEFAULT NULL,
  `employee_id` varchar(50) DEFAULT NULL,
  `start_day` varchar(50) DEFAULT NULL,
  `end_day` varchar(50) DEFAULT NULL,
  `requested_day` varchar(50) DEFAULT NULL,
  `designation` varchar(50) DEFAULT NULL,
  `leave_type` varchar(50) DEFAULT NULL,
  `leave_status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_leave`
--

LOCK TABLES `employee_leave` WRITE;
/*!40000 ALTER TABLE `employee_leave` DISABLE KEYS */;
INSERT INTO `employee_leave` VALUES (1,'Nikita Mane','1','20-01-2023','24-01-2024','Full Time','Manager','Medical Leave ','Cancelled'),(2,'Pranoti Salunkhe','2','23-01-2023','25-01-2024','Requested Day','HR','Leave Type','Approved'),(3,'Ankita Patil','3','22-01-2024','29-01-2024','Full Time','Developer','Personal Leave','Approved'),(4,'Pranali Patil','4','22-01-2024','29-01-2024','Requested Day','HR','Holiday','Cancelled'),(5,'Anushka Patil','5','30-01-2024','01-01-2024','Full Time','Manager','Medical Type','Approved'),(6,'Siya','6','02-01-2024','04-01-2024','Full Time','HR','Holiday','Approved'),(7,'Dhanashri Thorat','7','05-01-2024','07-01-2024','Requested Day','Manager','Medical Type','Approved'),(8,'Sarvesh Desai','8','07-01-2024','09-01-2024','Full Time','HR','Holiday','Approved'),(9,'Shri','9','15-01-2024','17-01-2024','Requested Day','Manager','Medical Type','Cancelled'),(10,'Ganesh','10','20-01-2024','24-01-2-24','Full Time','Manager','Holiday','Approved');
/*!40000 ALTER TABLE `employee_leave` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_loan`
--

DROP TABLE IF EXISTS `employee_loan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee_loan` (
  `loan_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` varchar(50) DEFAULT NULL,
  `employee_name` varchar(50) DEFAULT NULL,
  `email_id` varchar(50) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `mobile_no` varchar(50) DEFAULT NULL,
  `date_of_joining` varchar(50) DEFAULT NULL,
  `department` varchar(50) DEFAULT NULL,
  `designation` varchar(50) DEFAULT NULL,
  `required_date` varchar(50) DEFAULT NULL,
  `loan_type` varchar(50) DEFAULT NULL,
  `requested_amount` varchar(50) DEFAULT NULL,
  `bank_account_no` varchar(50) DEFAULT NULL,
  `installement_no` varchar(50) DEFAULT NULL,
  `mode_of_loan` varchar(50) DEFAULT NULL,
  `purpose_of_loan` varchar(50) DEFAULT NULL,
  `loan_details` varchar(500) DEFAULT NULL,
  `bank_details` varchar(500) DEFAULT NULL,
  `loan_status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`loan_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_loan`
--

LOCK TABLES `employee_loan` WRITE;
/*!40000 ALTER TABLE `employee_loan` DISABLE KEYS */;
INSERT INTO `employee_loan` VALUES (1,'1','Nikita Mane','nikita123@gmail.com','Walwa','1234567890','01-10-2021','Sells','Sells','01-03-2024','Health Loan','12000','012345','6','Health','Health Care','Doc11.docx','Doc11.docx','Cancelled'),(2,'2','Pranoti Salunkhe','pranali@gmail.com','Walwa','9087564321','03-10-2021','Manufacturing','Manufacturing','02-03-2024','Home Loan','23456','01234','9','Home','Home ','Doc11.docx','Doc11.docx','Cancelled'),(3,'3','Ankita Patil','ankitai@gmail.com','Islampur','6789054321','14-10-2021','Marketing','Worker','03-03-2024','Car Loan','45000','09876','12','Car','Car','Doc11.docx','Doc11.docx','Approved'),(4,'4','Pranali Thorat','pranali@gnail.com','Sangli','9078563412','11-12-2021','Security','Security','04-03-2024','Educational Loan','45000','01234','12','Educational','Education','Doc11.docx','Doc11.docx','Approved'),(5,'5','Anushka Patil','anu@gmail.com','Walwa','0987654321','12-12-2021','HR','HR','05-03-2024','Personnal Loan','30000','001243','10','Personal','Personal','Doc11.docx','Doc11.docx','Cancelled'),(6,'6','Siya','siya@gmail.com','Kolhapur','9080908989','14-12-2021','Marketing','Marketing','06-03-2024','Car Loan','20000','00128','11','Car','Car','Doc11.docx','Doc11.docx','Cancelled'),(7,'7','Dhanashri Thorat ','dhanu@gmail.com','Karad','9098909889','18-12-2021','Sells','Sells','07-03-2024','Educational Loan','12000','00178','10','Personal','Personal','Doc11.docx','Doc11.docx','Approved'),(8,'8','Sarvesh Desai','sarvesh@gmail.com','Walwa','8809788787','21-12-2021','Security','Security','08-03-2024','Personnal Loan','23000','00122','9','Educational','Educational','Doc11.docx','Doc11.docx','Cancelled'),(9,'9','Shri','shri@gmail.com','Islampur','9980776655','25-12-2021','HR','HR','09-03-2024','Car Loan','45000','00124','11','Personal','Personal','Doc11.docx','Doc11.docx','Approved'),(10,'10','Ganesh','ganesh@gmail.com','Islampur','9087654231','28-12-2021','Manufacturing','Manufacturing','10-03-2024','Health Loan','30000','00123','12','Car','Car','Doc11.docx','Doc11.docx','Approved');
/*!40000 ALTER TABLE `employee_loan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_registration`
--

DROP TABLE IF EXISTS `employee_registration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee_registration` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_name` varchar(50) DEFAULT NULL,
  `employee_id` varchar(50) DEFAULT NULL,
  `date_of_birth` varchar(90) DEFAULT NULL,
  `email_id` varchar(50) DEFAULT NULL,
  `mobile_no` bigint(50) DEFAULT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `highest_qualification` varchar(50) DEFAULT NULL,
  `designation` varchar(50) DEFAULT NULL,
  `adhar_no` bigint(50) DEFAULT NULL,
  `voting_no` bigint(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `cpassword` varchar(50) DEFAULT NULL,
  `applying_date` varchar(90) DEFAULT NULL,
  `type_of_work` varchar(50) DEFAULT NULL,
  `languages_spoken` varchar(50) DEFAULT NULL,
  `marital_status` varchar(50) DEFAULT NULL,
  `pancard_details` varchar(750) DEFAULT NULL,
  `bank_details` varchar(850) DEFAULT NULL,
  `resume` varchar(850) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_registration`
--

LOCK TABLES `employee_registration` WRITE;
/*!40000 ALTER TABLE `employee_registration` DISABLE KEYS */;
INSERT INTO `employee_registration` VALUES (1,'Nikita Mane','1','2024-04-18','nikita123@gmail.com',1234567890,'Female','Walwa','BCA','HR',98765,654321,'1428','1428','24-01-2024','HR','English','Unmarried','','','Doc11.docx'),(2,'Pranoti Salunkhe','2','23-05-2003','pranoti@gmail.com',9876543211,'Female','Islampur','BCA','Manufacturer',90876545,98765,'1234','1234','24-01-2024','Manufacturing','English','Unmarried','Doc11.docx','Doc11.docx','Doc11.docx'),(3,'Ankita Patl','3','12-10-2003','ankita@gmail.com',1234509876,'Female','Walwa','MCA','Developing',234567,907856,'1111','1111','10-03-2024','Developing','English','Unmarried','Doc11.docx','Doc11.docx','Doc11.docx'),(4,'Pranati Thorat','4','02-02-2002','pranali@gmail.com',6789012345,'Female','Islampur','BE','Marketing',123456,345678,'1212','1212','13-03-2024','Marketing','English','Unmarried','Doc11.docx','Doc11.docx','Doc11.docx'),(5,'Anushaka Patil','5','18-04-2000','anu@gmail.com',2345678901,'Female','Walwa','BCS','Manufacturing',987654,234567,'2222','2222','12-02-2024','Manufacturing','English','Unmarried','Doc11.docx','Doc11.docx','Doc11.docx'),(6,'Siya','6','12-02-2003','siya@gmail.com',9807654321,'Female','Kolhapur','BCA','Sells',98765,456789,'4321','4321','12-02-2024','Selling','Marathi, English','Unmarried','Doc11.docx','Doc11.docx','Doc11.docx'),(7,'Dhanashri Thorat','7','13-07-2001','dhanashri@gmail.com',9239459566,'Female','karad','B.Tech','Technician',345678,987654,'0909','0909','13-02-2024','Technical Work','English','Married','Doc11.docx','Doc11.docx','Doc11.docx'),(8,'Sarvesh Desai','8','06-06-2002','sarvesh@gmail.com',9123456780,'Male','pune','BCOM','Marketing',456789,789054,'9999','9999','14-02-2024','Merketing','English','Unmarried','Doc11.docx','Doc11.docx','Doc11.docx'),(9,'Shri','9','12-04-2004','shri@gmail.com',8906745231,'Male','pune','BCOM','HR',678900,234567,'1230','1230','14-02-2024','HR','English','Unmarried','Doc11.docx','Doc11.docx','Doc11.docx'),(10,'Ganesh','10','13-04-2000','ganesh@gmail',8907654321,'Male','mumbai','BCA','HR',907867,987654,'0000','0000','15-02-2024','HR','English','Married','Doc11.docx','Doc11.docx','Doc11.docx'),(11,'hp','11','14-10-1996','hp@gmail.com',8080158819,'Male','walwa',NULL,NULL,NULL,111111,'1414','1414','14-10-1996',NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `employee_registration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_salary`
--

DROP TABLE IF EXISTS `employee_salary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee_salary` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_name` varchar(50) DEFAULT NULL,
  `employee_id` varchar(50) DEFAULT NULL,
  `email_id` varchar(50) DEFAULT NULL,
  `mobile_no` varchar(50) DEFAULT NULL,
  `designation` varchar(50) DEFAULT NULL,
  `department` varchar(50) DEFAULT NULL,
  `da` varchar(50) DEFAULT NULL,
  `hra` varchar(50) DEFAULT NULL,
  `mid` varchar(50) DEFAULT NULL,
  `pf` varchar(50) DEFAULT NULL,
  `prof_tax` varchar(50) DEFAULT NULL,
  `advance` varchar(50) DEFAULT NULL,
  `lic` varchar(50) DEFAULT NULL,
  `canteen` varchar(50) DEFAULT NULL,
  `total_period` varchar(50) DEFAULT NULL,
  `m_day` varchar(50) DEFAULT NULL,
  `bank_acc_no` varchar(50) DEFAULT NULL,
  `select_month` varchar(50) DEFAULT NULL,
  `select_year` varchar(50) DEFAULT NULL,
  `earning` varchar(50) DEFAULT NULL,
  `deduction` varchar(50) DEFAULT NULL,
  `net_pay` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_salary`
--

LOCK TABLES `employee_salary` WRITE;
/*!40000 ALTER TABLE `employee_salary` DISABLE KEYS */;
INSERT INTO `employee_salary` VALUES (1,'Nikita Mane','1','nikita@gmail.com','0987654321','','','1500','300','3900','679','125','1000','45','340','24.0','31','0987654','March','2023','9123','1000','8123'),(2,'Pranoti Salunkhe','2','pranoti@gmail.com','9089890978','','','679','300','3900','679','125','1000','45','340','25.0','31','09876512','March','2023','12123','1000','11123'),(3,'Ankita Patil','3','ankita@gmail.com','0978654545',NULL,NULL,'779','400','3800','779','125','1000','55','350','25.0','31','0987651','March','2023','10123','1000','9123'),(4,'Pranali Thorat','4','pranali@gmail.com','8970678790',NULL,NULL,'779','400','3800','779','125','1000','55','350','24.0','31','0987652','March','2023','11123','2000','9123'),(5,'Anushka Patil','5','anu@gmail.com','9087789076',NULL,NULL,'679','300','3800','679','125','1000','45','340','24.0','31','0987655','March','2023','10123','1000','9123'),(6,'Siya','6','siya@gmail.com','7889907678',NULL,NULL,'679','300','3800','679','125','1000','45','340','24.0','31','0987650','March','2023','9123','1000','8123'),(7,'Dhanashri Thorat','7','dhanu@gmail.com','8998900967',NULL,NULL,'797','400','3700','679','125','1000','55','450','24.0','31','0987653','March','2023','10123','2000','8123'),(8,'Sarvesh Desai','8','sarvesh@gmail.com','7654890989',NULL,NULL,'679','300','3800','779','125','1000','55','500','25.0','31','0987659','March','2023','11123','2000','9123'),(9,'Ganesh ','9','ganesh@gmail.com','9000978990',NULL,NULL,'769','400','3500','679','125','1000','50','456','25.0','31','0987658','March','2023','10123','1000','10123'),(10,'Shri','10','shri@gmail.com','7890099090',NULL,NULL,'679','300','3900','779','125','1000','45','340','25.0','31','0987656','March','2023','8123','1000','7123'),(11,'Nikita ','1','nikita123@gmail.com','0987654321','Manager','','','2134','1234','340','234','1000','200','120','21','31','March','2021','8900','1000','09876543','7900'),(12,'','','','','','','','','','','','','','','','','','','','','','7900');
/*!40000 ALTER TABLE `employee_salary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password`
--

DROP TABLE IF EXISTS `password`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `email_id` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `cpassword` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password`
--

LOCK TABLES `password` WRITE;
/*!40000 ALTER TABLE `password` DISABLE KEYS */;
INSERT INTO `password` VALUES (1,'abc@gmail.com','1234','1234'),(2,'rs@gmail.com','123','123'),(3,'xyz@gmail.com','abcd','abcd'),(4,'asdf@gmail.com','0909','0909'),(5,'nhp123@gmail.com','8907','8907'),(6,'123@gmail.com','asas','asas'),(7,'arjun@gmail.com','azq','azq'),(8,'jeet@gmail.com','1a1a','1a1a'),(9,'anita@gmail.com','000','000'),(10,'sonu@gmail.com','sonu','sonu');
/*!40000 ALTER TABLE `password` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-20  9:44:13
